package com.majma.darktunneltoggle;

import android.content.Intent;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class DarkTunnelTileService extends TileService {
    @Override public void onStartListening() {
        super.onStartListening();
        Tile t = getQsTile();
        if (t != null) { t.setLabel("DarkTunnel VPN"); t.setState(Tile.STATE_INACTIVE); t.updateTile(); }
    }
    @Override public void onClick() {
        super.onClick();
        Intent request = new Intent(TunnelAccessibilityService.ACTION_TOGGLE);
        request.setPackage(getPackageName());
        sendBroadcast(request);
        if (getQsTile() != null) { getQsTile().setState(Tile.STATE_ACTIVE); getQsTile().updateTile(); }
    }
}
