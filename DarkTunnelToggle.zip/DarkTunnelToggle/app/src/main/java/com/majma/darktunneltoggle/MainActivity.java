package com.majma.darktunneltoggle;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("DarkTunnel Toggle"); title.setTextSize(26);
        TextView info = new TextView(this);
        info.setText("أضف زر DarkTunnel VPN إلى لوحة الاختصارات.\n\nحتى يعمل الزر، فعّل خدمة إمكانية الوصول لهذا التطبيق فقط. الخدمة مقيّدة بتطبيق DarkTunnel وتبحث عن زري CONNECT وDISCONNECT فقط.\n\nتنبيه: هذه نسخة تجريبية؛ قد تحتاج أن تكون شاشة DarkTunnel ظاهرة حتى يتم الضغط على الزر.");
        info.setTextSize(17); info.setPadding(0, 28, 0, 28);
        Button access = new Button(this); access.setText("فتح إعدادات إمكانية الوصول");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button tile = new Button(this); tile.setText("فتح DarkTunnel");
        tile.setOnClickListener(v -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("net.darktunnel.app");
            if (i != null) startActivity(i);
        });
        layout.addView(title); layout.addView(info); layout.addView(access); layout.addView(tile);
        setContentView(layout);
    }
}
