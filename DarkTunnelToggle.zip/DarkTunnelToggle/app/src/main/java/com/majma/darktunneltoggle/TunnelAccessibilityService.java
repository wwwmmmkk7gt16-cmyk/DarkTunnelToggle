package com.majma.darktunneltoggle;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public class TunnelAccessibilityService extends AccessibilityService {
    public static final String ACTION_TOGGLE = "com.majma.darktunneltoggle.TOGGLE";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pending = false;
    private long lastTapAt = 0;
    private int attempts = 0;
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_TOGGLE.equals(intent.getAction())) return;
            pending = true;
            attempts = 0;
            Intent launch = getPackageManager().getLaunchIntentForPackage("net.darktunnel.app");
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(launch);
                handler.postDelayed(() -> tryTapButton(), 900);
            } else {
                pending = false;
            }
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        IntentFilter filter = new IntentFilter(ACTION_TOGGLE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!pending || event == null || !"net.darktunnel.app".contentEquals(event.getPackageName())) return;
        handler.postDelayed(this::tryTapButton, 250);
    }

    private void tryTapButton() {
        if (!pending) return;
        if (attempts++ >= 12) { pending = false; return; }
        if (System.currentTimeMillis() - lastTapAt < 1800) { pending = false; return; }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !"net.darktunnel.app".contentEquals(root.getPackageName())) return;
        // Prefer exact visible button labels; never tap unrelated controls.
        String[] labels = {"CONNECT", "DISCONNECT", "Connect", "Disconnect"};
        for (String label : labels) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(label);
            if (nodes == null) continue;
            for (AccessibilityNodeInfo node : nodes) {
                if (node == null || !node.isVisibleToUser() || !node.isEnabled()) continue;
                AccessibilityNodeInfo clickable = node;
                while (clickable != null && !clickable.isClickable()) clickable = clickable.getParent();
                if (clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    lastTapAt = System.currentTimeMillis(); pending = false; return;
                }
            }
        }
        // Keep waiting for the app's main screen to finish rendering, for up to a few seconds.
        handler.postDelayed(() -> {
            if (pending) tryTapButton();
        }, 500);
    }

    @Override public void onInterrupt() { pending = false; }

    @Override public void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
